package com.zybooks.weightlossandgoal;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class WeightProgress extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.class_layout.MESSAGE";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight_progress);


        //Get the Intent that started this activity and extract the string
        Intent intent = getIntent();

        String message = intent.getStringExtra("data1");
        String message1 = intent.getStringExtra("data2");
        String message2 = intent.getStringExtra("data3");


        //Capture the layout's TextView and set the String as its text
        TextView textView = findViewById(R.id.DateEntry1);
        TextView textView1 = findViewById(R.id.WeightEntry1);
        TextView textView2 = findViewById(R.id.DesiredWeight1);
        textView.setText(message);
        textView1.setText(message1);
        textView2.setText(message2);



    }


}